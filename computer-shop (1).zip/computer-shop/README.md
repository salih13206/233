# Магазин компьютерных комплектующих

Итоговая практическая работа по React.

**Студент:** ФИО _(впиши своё)_
**Группа:** _(впиши свою)_

## Тема
Магазин компьютерных комплектующих. Пользователь может смотреть каталог, зарегистрироваться
и управлять своими комплектующими (CRUD). Отдельная страница показывает ноутбуки из внешнего API.

Сущность CRUD — **Комплектующее**: тип, модель, совместимость, цена, описание.

## Стек
- Frontend: React 18, React Router DOM 6, Vite, обычный CSS
- Backend: Node.js, Express, JSON-файл как хранилище (`server/data/db.json`)
- Авторизация: bcryptjs (хеш пароля) + JWT в HttpOnly cookie
- Внешний API: DummyJSON `https://dummyjson.com/products/category/laptops`

## Структура
```
computer-shop/
├── server/
│   ├── index.js            сервер, API, авторизация, проверка владельца
│   └── data/db.json        создаётся автоматически при первом запуске
└── client/src/
    ├── pages/              страницы
    ├── components/         Layout, Navbar, ProtectedRoute, ItemCard, ItemForm
    ├── context/            AuthContext
    ├── services/           api.js (запросы), constants.js
    └── styles/style.css
```

## Запуск
Нужен Node.js 18+. Открыть два терминала.

**1. Сервер**
```
cd server
npm install
npm start
```
Сервер: http://localhost:5000

**2. Клиент**
```
cd client
npm install
npm run dev
```
Сайт: http://localhost:5173

Тестовый пользователь: `demo@shop.local` / `demo123` (создаётся при первом запуске).

## Маршруты
| Адрес | Описание | Доступ |
|---|---|---|
| `/` | Главная | все |
| `/items` | Каталог, поиск и фильтр по типу | все |
| `/items/:id` | Страница комплектующего | все |
| `/explore` | Ноутбуки из DummyJSON (поиск, сортировка, повтор при ошибке) | все |
| `/register`, `/login` | Регистрация и вход | все |
| `/dashboard` | Мои комплектующие | только вошедшие |
| `/dashboard/new` | Создание | только вошедшие |
| `/dashboard/edit/:id` | Редактирование | только владелец |
| `*` | 404 | все |

## API сервера
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `GET /api/items`, `GET /api/items/:id` — публично
- `GET /api/my/items`, `POST /api/items`, `PUT /api/items/:id`, `DELETE /api/items/:id` — нужен вход;
  PUT и DELETE работают только для владельца записи (иначе 403)

## Внешний API
`GET https://dummyjson.com/products/category/laptops` — в этой категории всего 5 товаров,
выводятся все. Поля, которые используются: `title` (модель), `category` (тип), `brand`, `price`,
`rating`, `thumbnail`. Поля «совместимость» в API нет, вместо него показан бренд.
В запросе используется `AbortController`, есть состояния loading / error / empty и кнопка «Повторить».
