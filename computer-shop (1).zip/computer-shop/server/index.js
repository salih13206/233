// Сервер магазина компьютерных комплектующих (Express + JSON-файл)
import express from 'express';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = path.join(__dirname, 'data', 'db.json');
const PORT = 5000;
const SECRET = process.env.JWT_SECRET || 'my-student-secret'; // для учебного проекта

const app = express();
app.use(express.json());
app.use(cookieParser());

// ---------- работа с "базой" (JSON-файл) ----------
function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// если файла нет - создаём и кладём тестовые данные
function initDB() {
  if (fs.existsSync(DB_FILE)) return;
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

  const demoUser = {
    id: 1,
    name: 'Demo',
    email: 'demo@shop.local',
    passwordHash: bcrypt.hashSync('demo123', 10),
  };

  const items = [
    { id: 1, ownerId: 1, type: 'Процессор', model: 'AMD Ryzen 5 5600', compatibility: 'Сокет AM4', price: 12500, description: '6 ядер, 12 потоков' },
    { id: 2, ownerId: 1, type: 'Видеокарта', model: 'NVIDIA GeForce RTX 4060', compatibility: 'PCI-E 4.0 x8, БП от 550 Вт', price: 32000, description: '8 ГБ GDDR6' },
    { id: 3, ownerId: 1, type: 'Оперативная память', model: 'Kingston Fury 16GB DDR4', compatibility: 'DDR4, 3200 МГц', price: 3800, description: 'Комплект 2x8 ГБ' },
  ];

  writeDB({ users: [demoUser], items, nextUserId: 2, nextItemId: 4 });
}
initDB();

// ---------- middleware: проверка входа ----------
function auth(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: 'Нужно войти в аккаунт' });
  try {
    req.userId = jwt.verify(token, SECRET).id;
    next();
  } catch (e) {
    res.status(401).json({ message: 'Сессия недействительна' });
  }
}

function setToken(res, user) {
  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 3600 * 1000 });
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email };
}

// ---------- авторизация ----------
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Заполните все поля' });
  }
  if (!email.includes('@')) {
    return res.status(400).json({ message: 'Некорректный email' });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: 'Пароль минимум 6 символов' });
  }

  const db = readDB();
  if (db.users.find((u) => u.email === email.toLowerCase())) {
    return res.status(409).json({ message: 'Такой email уже зарегистрирован' });
  }

  const user = {
    id: db.nextUserId++,
    name,
    email: email.toLowerCase(),
    passwordHash: bcrypt.hashSync(password, 10), // пароль в открытом виде не храним
  };
  db.users.push(user);
  writeDB(db);

  setToken(res, user);
  res.status(201).json(publicUser(user));
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find((u) => u.email === (email || '').toLowerCase());

  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.status(401).json({ message: 'Неверный email или пароль' });
  }

  setToken(res, user);
  res.json(publicUser(user));
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'ok' });
});

// восстановление сессии после перезагрузки страницы
app.get('/api/auth/me', auth, (req, res) => {
  const user = readDB().users.find((u) => u.id === req.userId);
  if (!user) return res.status(401).json({ message: 'Пользователь не найден' });
  res.json(publicUser(user));
});

// ---------- проверка полей комплектующего ----------
function validateItem(body) {
  const { type, model, compatibility, price } = body;
  if (!type || !model || !compatibility) {
    return 'Заполните тип, модель и совместимость';
  }
  if (price === '' || price === undefined || isNaN(Number(price)) || Number(price) < 0) {
    return 'Цена должна быть числом не меньше 0';
  }
  return null;
}

function addOwnerName(item, users) {
  const owner = users.find((u) => u.id === item.ownerId);
  return { ...item, ownerName: owner ? owner.name : 'неизвестно' };
}

// ---------- CRUD комплектующих ----------
// READ: все (публично)
app.get('/api/items', (req, res) => {
  const db = readDB();
  res.json(db.items.map((i) => addOwnerName(i, db.users)));
});

// READ: только мои
app.get('/api/my/items', auth, (req, res) => {
  const db = readDB();
  res.json(db.items.filter((i) => i.ownerId === req.userId));
});

// READ: одна запись
app.get('/api/items/:id', (req, res) => {
  const db = readDB();
  const item = db.items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: 'Комплектующее не найдено' });
  res.json(addOwnerName(item, db.users));
});

// CREATE
app.post('/api/items', auth, (req, res) => {
  const error = validateItem(req.body);
  if (error) return res.status(400).json({ message: error });

  const db = readDB();
  const item = {
    id: db.nextItemId++,
    ownerId: req.userId,
    type: req.body.type,
    model: req.body.model,
    compatibility: req.body.compatibility,
    price: Number(req.body.price),
    description: req.body.description || '',
  };
  db.items.push(item);
  writeDB(db);
  res.status(201).json(item);
});

// UPDATE (только владелец)
app.put('/api/items/:id', auth, (req, res) => {
  const db = readDB();
  const item = db.items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: 'Комплектующее не найдено' });
  if (item.ownerId !== req.userId) {
    return res.status(403).json({ message: 'Нельзя менять чужую запись' });
  }

  const error = validateItem(req.body);
  if (error) return res.status(400).json({ message: error });

  item.type = req.body.type;
  item.model = req.body.model;
  item.compatibility = req.body.compatibility;
  item.price = Number(req.body.price);
  item.description = req.body.description || '';
  writeDB(db);
  res.json(item);
});

// DELETE (только владелец)
app.delete('/api/items/:id', auth, (req, res) => {
  const db = readDB();
  const item = db.items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: 'Комплектующее не найдено' });
  if (item.ownerId !== req.userId) {
    return res.status(403).json({ message: 'Нельзя удалять чужую запись' });
  }

  db.items = db.items.filter((i) => i.id !== item.id);
  writeDB(db);
  res.json({ message: 'Удалено' });
});

app.listen(PORT, () => console.log('Сервер запущен: http://localhost:' + PORT));
