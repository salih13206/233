import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// запросы /api уходят на Express-сервер (так cookie работают без CORS)
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://localhost:5000',
    },
  },
});
