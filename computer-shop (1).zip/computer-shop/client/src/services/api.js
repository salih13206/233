// Все запросы к нашему серверу собраны здесь

async function request(url, method = 'GET', body) {
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // чтобы отправлялась cookie с токеном
  };
  if (body) options.body = JSON.stringify(body);

  const response = await fetch(url, options);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Ошибка запроса');
  }
  return data;
}

// авторизация
export const registerUser = (data) => request('/api/auth/register', 'POST', data);
export const loginUser = (data) => request('/api/auth/login', 'POST', data);
export const logoutUser = () => request('/api/auth/logout', 'POST');
export const getMe = () => request('/api/auth/me');

// комплектующие
export const getItems = () => request('/api/items');
export const getMyItems = () => request('/api/my/items');
export const getItem = (id) => request('/api/items/' + id);
export const createItem = (data) => request('/api/items', 'POST', data);
export const updateItem = (id, data) => request('/api/items/' + id, 'PUT', data);
export const deleteItem = (id) => request('/api/items/' + id, 'DELETE');
