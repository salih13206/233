import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import Items from './pages/Items.jsx';
import ItemDetails from './pages/ItemDetails.jsx';
import Explore from './pages/Explore.jsx';
import Register from './pages/Register.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import ItemCreate from './pages/ItemCreate.jsx';
import ItemEdit from './pages/ItemEdit.jsx';
import NotFound from './pages/NotFound.jsx';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        {/* публичные страницы */}
        <Route index element={<Home />} />
        <Route path="items" element={<Items />} />
        <Route path="items/:id" element={<ItemDetails />} />
        <Route path="explore" element={<Explore />} />
        <Route path="register" element={<Register />} />
        <Route path="login" element={<Login />} />

        {/* закрытые страницы (вложенные в ProtectedRoute) */}
        <Route element={<ProtectedRoute />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="dashboard/new" element={<ItemCreate />} />
          <Route path="dashboard/edit/:id" element={<ItemEdit />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

export default App;
