import { Outlet } from 'react-router-dom';
import Navbar from './Navbar.jsx';

function Layout() {
  return (
    <div>
      <Navbar />
      <main className="container">
        <Outlet />
      </main>
      <footer className="footer">Магазин комплектующих — учебный проект</footer>
    </div>
  );
}

export default Layout;
