import { useState } from 'react';
import { TYPES } from '../services/constants.js';

// Общая форма для создания и редактирования
// props: initialValues, onSubmit, buttonText
function ItemForm({ initialValues, onSubmit, buttonText }) {
  const [form, setForm] = useState(
    initialValues || { type: TYPES[0], model: '', compatibility: '', price: '', description: '' }
  );
  const [error, setError] = useState('');

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    // проверка на клиенте
    if (form.model.trim() === '' || form.compatibility.trim() === '') {
      setError('Заполните модель и совместимость');
      return;
    }
    if (form.price === '' || Number(form.price) < 0) {
      setError('Укажите корректную цену');
      return;
    }

    try {
      await onSubmit(form);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="form">
      <label htmlFor="type">Тип</label>
      <select id="type" name="type" value={form.type} onChange={handleChange}>
        {TYPES.map((t) => (
          <option key={t} value={t}>{t}</option>
        ))}
      </select>

      <label htmlFor="model">Модель</label>
      <input id="model" name="model" value={form.model} onChange={handleChange} required />

      <label htmlFor="compatibility">Совместимость</label>
      <input id="compatibility" name="compatibility" value={form.compatibility} onChange={handleChange} placeholder="например: сокет AM4" required />

      <label htmlFor="price">Цена, ₽</label>
      <input id="price" name="price" type="number" min="0" value={form.price} onChange={handleChange} required />

      <label htmlFor="description">Описание</label>
      <textarea id="description" name="description" value={form.description} onChange={handleChange} rows="3" />

      {error && <p className="error">{error}</p>}
      <button type="submit">{buttonText}</button>
    </form>
  );
}

export default ItemForm;
