import { Link } from 'react-router-dom';

// карточка комплектующего: Компонент (тип, модель, совместимость, цена)
function ItemCard({ item }) {
  return (
    <div className="card">
      <span className="badge">{item.type}</span>
      <h3>{item.model}</h3>
      <p>Совместимость: {item.compatibility}</p>
      <p className="price">{item.price} ₽</p>
      <Link className="btn" to={'/items/' + item.id}>Подробнее</Link>
    </div>
  );
}

export default ItemCard;
