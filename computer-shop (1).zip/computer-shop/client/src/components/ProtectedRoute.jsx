import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

function ProtectedRoute() {
  const { user, loading } = useAuth();
  const location = useLocation();

  // пока сессия проверяется, ничего не решаем
  if (loading) return <p>Загрузка...</p>;

  // гость -> на страницу входа, запоминаем откуда пришёл
  if (!user) return <Navigate to="/login" state={{ from: location.pathname }} replace />;

  return <Outlet />;
}

export default ProtectedRoute;
