import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/');
  }

  return (
    <nav className="navbar">
      <b className="brand">PC Комплектующие</b>
      <NavLink to="/">Главная</NavLink>
      <NavLink to="/items">Каталог</NavLink>
      <NavLink to="/explore">Ноутбуки (API)</NavLink>

      {user ? (
        <>
          <NavLink to="/dashboard">Мои товары</NavLink>
          <span className="right">Привет, {user.name}!</span>
          <button className="btn-light" onClick={handleLogout}>Выйти</button>
        </>
      ) : (
        <>
          <NavLink to="/login" className="right">Вход</NavLink>
          <NavLink to="/register">Регистрация</NavLink>
        </>
      )}
    </nav>
  );
}

export default Navbar;
