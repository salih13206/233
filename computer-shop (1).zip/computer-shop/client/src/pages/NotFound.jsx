import { Link } from 'react-router-dom';

function NotFound() {
  return (
    <div>
      <h1>404</h1>
      <p>Такой страницы нет.</p>
      <Link to="/">На главную</Link>
    </div>
  );
}

export default NotFound;
