import { useNavigate } from 'react-router-dom';
import { createItem } from '../services/api.js';
import ItemForm from '../components/ItemForm.jsx';

function ItemCreate() {
  const navigate = useNavigate();

  async function handleCreate(form) {
    await createItem(form);
    navigate('/dashboard');
  }

  return (
    <div>
      <h1>Новое комплектующее</h1>
      <ItemForm onSubmit={handleCreate} buttonText="Создать" />
    </div>
  );
}

export default ItemCreate;
