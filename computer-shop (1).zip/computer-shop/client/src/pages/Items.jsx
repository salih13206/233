import { useState, useEffect } from 'react';
import { getItems } from '../services/api.js';
import { TYPES } from '../services/constants.js';
import ItemCard from '../components/ItemCard.jsx';

function Items() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  useEffect(() => {
    getItems()
      .then((data) => setItems(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  // фильтрация считается из данных, отдельно в state не храним
  const filtered = items.filter((item) => {
    const matchSearch = item.model.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === '' || item.type === typeFilter;
    return matchSearch && matchType;
  });

  if (loading) return <p>Загрузка...</p>;
  if (error) return <p className="error">{error}</p>;

  return (
    <div>
      <h1>Каталог комплектующих</h1>

      <div className="filters">
        <input
          placeholder="Поиск по модели"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="">Все типы</option>
          {TYPES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p>Ничего не найдено</p>
      ) : (
        <div className="grid">
          {filtered.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Items;
