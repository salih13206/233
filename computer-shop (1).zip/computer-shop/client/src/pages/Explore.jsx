import { useState, useEffect } from 'react';

// Внешний API: DummyJSON, категория laptops
const API_URL = 'https://dummyjson.com/products/category/laptops';

function Explore() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('none');
  const [attempt, setAttempt] = useState(0); // меняем при нажатии "Повторить"

  useEffect(() => {
    const controller = new AbortController(); // чтобы отменять старый запрос
    setLoading(true);
    setError('');

    fetch(API_URL, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error('Ошибка сервера: ' + res.status);
        return res.json();
      })
      .then((data) => {
        setProducts(data.products);
        setLoading(false);
      })
      .catch((err) => {
        if (err.name === 'AbortError') return; // запрос отменён - ничего не делаем
        setError('Не удалось загрузить данные. ' + err.message);
        setLoading(false);
      });

    return () => controller.abort();
  }, [attempt]);

  // поиск и сортировка по уже загруженным данным
  let shown = products.filter((p) => p.title.toLowerCase().includes(search.toLowerCase()));
  if (sort === 'asc') shown = [...shown].sort((a, b) => a.price - b.price);
  if (sort === 'desc') shown = [...shown].sort((a, b) => b.price - a.price);

  return (
    <div>
      <h1>Ноутбуки (внешний API DummyJSON)</h1>

      <div className="filters">
        <input
          placeholder="Поиск по модели"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="none">Без сортировки</option>
          <option value="asc">Сначала дешёвые</option>
          <option value="desc">Сначала дорогие</option>
        </select>
      </div>

      {loading && <p>Загрузка...</p>}

      {error && (
        <div>
          <p className="error">{error}</p>
          <button onClick={() => setAttempt(attempt + 1)}>Повторить</button>
        </div>
      )}

      {!loading && !error && shown.length === 0 && <p>Ничего не найдено</p>}

      <div className="grid">
        {shown.map((p) => (
          <div className="card" key={p.id}>
            <img src={p.thumbnail} alt={p.title} />
            {/* Компонент: тип, модель, совместимость, цена */}
            <span className="badge">{p.category}</span>
            <h3>{p.title}</h3>
            {/* в API нет поля "совместимость", поэтому берём бренд */}
            <p>Совместимость: {p.brand}</p>
            <p className="price">${p.price}</p>
            <p>Рейтинг: {p.rating}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Explore;
