import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getMyItems, deleteItem } from '../services/api.js';

function Dashboard() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getMyItems()
      .then(setItems)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  async function handleDelete(id) {
    if (!window.confirm('Точно удалить это комплектующее?')) return;
    try {
      await deleteItem(id);
      setItems(items.filter((i) => i.id !== id)); // убираем из списка
    } catch (err) {
      setError(err.message);
    }
  }

  if (loading) return <p>Загрузка...</p>;

  return (
    <div>
      <div className="top-bar">
        <h1>Мои комплектующие</h1>
        <Link to="/dashboard/new" className="btn">+ Добавить комплектующее</Link>
      </div>

      {error && <p className="error">{error}</p>}

      {items.length === 0 ? (
        <p>У вас пока нет товаров</p>
      ) : (
        <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Тип</th>
              <th>Модель</th>
              <th>Совместимость</th>
              <th>Цена</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id}>
                <td>{item.type}</td>
                <td>{item.model}</td>
                <td>{item.compatibility}</td>
                <td>{item.price} ₽</td>
                <td>
                  <Link className="btn btn-light" to={'/dashboard/edit/' + item.id}>Изменить</Link>{' '}
                  <button className="btn-danger" onClick={() => handleDelete(item.id)}>Удалить</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
