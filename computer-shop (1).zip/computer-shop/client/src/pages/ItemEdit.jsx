import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getItem, updateItem } from '../services/api.js';
import ItemForm from '../components/ItemForm.jsx';

function ItemEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getItem(id)
      .then(setItem)
      .catch((err) => setError(err.message));
  }, [id]);

  async function handleUpdate(form) {
    // если чужая запись - сервер вернёт 403 и ошибка покажется в форме
    await updateItem(id, form);
    navigate('/dashboard');
  }

  if (error) return <p className="error">{error}</p>;
  if (!item) return <p>Загрузка...</p>;

  return (
    <div>
      <h1>Редактирование: {item.model}</h1>
      <ItemForm initialValues={item} onSubmit={handleUpdate} buttonText="Сохранить" />
    </div>
  );
}

export default ItemEdit;
