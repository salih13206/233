import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getItems } from '../services/api.js';
import ItemCard from '../components/ItemCard.jsx';

function Home() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    getItems().then(setItems).catch(() => setItems([]));
  }, []);

  // на главной показываем только 3 последних товара
  const lastItems = items.slice(-3);

  return (
    <div>
      <div className="hero">
        <h1>Магазин компьютерных комплектующих</h1>
        <p>
          На сайте можно посмотреть каталог комплектующих (процессоры, видеокарты, память и другое),
          зарегистрироваться и добавлять свои товары. Также есть страница с ноутбуками из внешнего API.
        </p>
        <Link className="btn" to="/items">Весь каталог</Link>
        <Link className="btn" to="/explore">Ноутбуки из API</Link>
      </div>

      <h2>Последние добавленные</h2>
      {lastItems.length === 0 ? (
        <p>Пока ничего нет</p>
      ) : (
        <div className="grid">
          {lastItems.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;
