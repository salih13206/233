import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getItem } from '../services/api.js';

function ItemDetails() {
  const { id } = useParams(); // берём id из адреса /items/:id
  const [item, setItem] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getItem(id)
      .then(setItem)
      .catch((err) => setError(err.message));
  }, [id]);

  if (error) {
    return (
      <div>
        <p className="error">{error}</p>
        <Link to="/items">← К каталогу</Link>
      </div>
    );
  }
  if (!item) return <p>Загрузка...</p>;

  return (
    <div>
      <h1>{item.model}</h1>
      <div className="details">
        <p><b>Тип:</b> {item.type}</p>
        <p><b>Модель:</b> {item.model}</p>
        <p><b>Совместимость:</b> {item.compatibility}</p>
        <p className="price">{item.price} ₽</p>
        <p><b>Описание:</b> {item.description || 'нет'}</p>
        <p><b>Добавил:</b> {item.ownerName}</p>
      </div>
      <Link to="/items">← К каталогу</Link>
    </div>
  );
}

export default ItemDetails;
